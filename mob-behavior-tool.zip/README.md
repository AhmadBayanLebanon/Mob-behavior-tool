Mob Behavior Tool - Fabric mod (1.21.9)

This archive contains a Fabric mod project skeleton. Build using Gradle/Loom for Minecraft 1.21.9.
