package com.example.mobbehaviortool;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AggressivityMod implements ModInitializer {
    public static final String MODID = "mobbehaviortool";
    public static final Logger LOGGER = LoggerFactory.getLogger(MODID);

    private static int tickCounter = 0;

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Mob Behavior Tool");

        ModItems.registerItems();

        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient) return ActionResult.PASS;
            if (!(entity instanceof LivingEntity)) return ActionResult.PASS;
            if (player.getStackInHand(hand).getItem() == ModItems.AGGRESSIVITY_CHANGER) {
                LivingEntity mob = (LivingEntity) entity;
                MobAggressivityComponent comp = MobAggressivityComponent.get(mob);
                comp.cycleState();
                if (player instanceof ServerPlayerEntity) {
                    ((ServerPlayerEntity) player).sendMessage(Text.of("Aggressivity -> " + comp.getState().name()), false);
                }
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });

        ServerEntityEvents.ENTITY_LOAD.register((entity, serverWorld) -> {
            if (entity instanceof LivingEntity) {
                MobAggressivityComponent.get((LivingEntity) entity);
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickCounter = (tickCounter + 1) % 20;
            if (tickCounter != 0) return;
            for (ServerWorld world : server.getWorlds()) {
                world.iterateEntities(LivingEntity.class, e -> true).forEach(e -> {
                    MobAggressivityComponent comp = MobAggressivityComponent.get(e);
                    if (comp.getState() == AggressivityState.FULLY_AGGRESSIVE) comp.applyAggressiveBehavior();
                });
            }
        });

        LOGGER.info("Mob Behavior Tool initialized");
    }
}
