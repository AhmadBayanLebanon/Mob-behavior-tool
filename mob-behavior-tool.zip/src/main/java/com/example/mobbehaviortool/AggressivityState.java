package com.example.mobbehaviortool;

public enum AggressivityState {
    PASSIVE,
    NATURAL,
    FULLY_AGGRESSIVE,
    NORMAL
}
