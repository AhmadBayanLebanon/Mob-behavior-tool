package com.example.mobbehaviortool;

import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModItems {
    public static final Item AGGRESSIVITY_CHANGER = new AggressivityChangerItem(new Item.Settings().maxCount(1).group(ItemGroup.MISC));

    public static void registerItems() {
        Registry.register(Registry.ITEM, new Identifier("mobbehaviortool", "aggressivity_changer"), AGGRESSIVITY_CHANGER);
    }
}
