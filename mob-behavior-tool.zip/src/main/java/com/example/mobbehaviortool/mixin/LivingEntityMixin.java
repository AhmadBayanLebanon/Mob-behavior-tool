package com.example.mobbehaviortool.mixin;

import com.example.mobbehaviortool.MobAggressivityComponent;
import com.example.mobbehaviortool.AggressivityState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.nbt.NbtCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void onWriteCustomDataToNbt(NbtCompound tag, CallbackInfo ci) {
        LivingEntity self = (LivingEntity)(Object)this;
        MobAggressivityComponent comp = MobAggressivityComponent.get(self);
        comp.writeToNbt(tag);
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void onReadCustomDataFromNbt(NbtCompound tag, CallbackInfo ci) {
        LivingEntity self = (LivingEntity)(Object)this;
        MobAggressivityComponent comp = MobAggressivityComponent.get(self);
        comp.readFromNbt(tag);
    }

    @Redirect(method = "setTarget", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;setTarget(Lnet/minecraft/entity/LivingEntity;)V"))
    private void redirectSetTarget(LivingEntity instance, LivingEntity target) {
        MobAggressivityComponent comp = MobAggressivityComponent.get(instance);
        AggressivityState state = comp.getState();

        if (state == AggressivityState.PASSIVE) {
            return;
        }
        try {
            java.lang.reflect.Method setTarget = instance.getClass().getMethod("setTarget", LivingEntity.class);
            setTarget.invoke(instance, target);
        } catch (Exception ignored) {}
    }
}
